package com.ipartek.bootColegio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootColegioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootColegioApplication.class, args);
	}
}
