package com.ipartek.bootColegio.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ipartek.bootColegio.model.Alumno;



public interface AlumnoRepository extends JpaRepository<Alumno, Integer> {


	
}
